// @ts-check
const { S3Client, PutObjectCommand } = require("@aws-sdk/client-s3");
const { SNSClient, PublishCommand } = require("@aws-sdk/client-sns");

const s3 = new S3Client({ region: "ap-southeast-2" });
const sns = new SNSClient({ region: "ap-southeast-2" });

// Simple Google Books API validation (you'd need to add API key)
async function validateWithGoogleBooks(title, author) {
  try {
    const query = encodeURIComponent(`"${title}" "${author}"`);
    const response = await fetch(
      `https://www.googleapis.com/books/v1/volumes?q=${query}&maxResults=1`
    );
    const data = await response.json();

    if (data.items && data.items.length > 0) {
      const book = data.items[0].volumeInfo;
      return {
        validated: true,
        title: book.title,
        authors: book.authors,
        isbn: book.industryIdentifiers?.[0]?.identifier,
        publishedDate: book.publishedDate,
        publisher: book.publisher,
        thumbnail: book.imageLinks?.thumbnail,
      };
    }

    return { validated: false };
  } catch (error) {
    console.error("Google Books validation error:", error);
    return { validated: false, error: error.message };
  }
}

exports.handler = async (event) => {
  console.log("Book Validator triggered:", JSON.stringify(event, null, 2));

  for (const record of event.Records) {
    const message = JSON.parse(record.body);
    const { jobId, candidates } = message;

    console.log(`Validating ${candidates.length} candidates for job: ${jobId}`);

    try {
      const validatedBooks = [];

      // Validate each candidate
      for (const candidate of candidates) {
        console.log(`Validating: "${candidate.title}" by ${candidate.author}`);

        const validation = await validateWithGoogleBooks(
          candidate.title,
          candidate.author
        );

        if (validation.validated) {
          validatedBooks.push({
            ...candidate,
            validation: validation,
            status: "validated",
          });
        } else {
          validatedBooks.push({
            ...candidate,
            validation: validation,
            status: "unvalidated",
          });
        }
      }

      const finalResults = {
        jobId: jobId,
        timestamp: new Date().toISOString(),
        totalCandidates: candidates.length,
        validatedCount: validatedBooks.filter((b) => b.status === "validated")
          .length,
        books: validatedBooks,
      };

      console.log(
        `Validation complete: ${finalResults.validatedCount}/${finalResults.totalCandidates} books validated`
      );

      // Store final results
      const resultsBucket = process.env.RESULTS_BUCKET_NAME;
      await s3.send(
        new PutObjectCommand({
          Bucket: resultsBucket,
          Key: `${jobId}/final-results.json`,
          Body: JSON.stringify(finalResults, null, 2),
          ContentType: "application/json",
        })
      );

      // Publish completion notification
      await sns.send(
        new PublishCommand({
          TopicArn: process.env.SNS_TOPIC_ARN,
          Subject: `BookImg Processing Complete - Job ${jobId}`,
          Message: JSON.stringify(
            {
              jobId: jobId,
              status: "complete",
              validatedBooks: finalResults.validatedCount,
              totalCandidates: finalResults.totalCandidates,
              resultsLocation: `s3://${resultsBucket}/${jobId}/final-results.json`,
            },
            null,
            2
          ),
        })
      );

      console.log(`Published completion notification for job: ${jobId}`);
    } catch (error) {
      console.error(`Error validating books for job ${jobId}:`, error);
      throw error;
    }
  }

  return { statusCode: 200, body: "Book validation complete" };
};
